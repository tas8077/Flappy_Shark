package com.example.demo3;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Random;

public class GameController {
    @FXML
    private Pane gamePane;

    @FXML
    private Rectangle shark;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label gameOverLabel;

    @FXML
    private Label clickToStartLabel;

    @FXML
    private ImageView sharkIMG;

    private double sharkVelocity = 0;
    private int score = 0;
    private AnimationTimer gameLoop;
    private ArrayList<Rectangle[]> columns;
    private Random random;
    private final double columnWidth = 60;
    private final double gapHeight = 200;
    private final double columnSpacing = 300;
    private boolean gameStarted = false;

    @FXML
    public void initialize() {
        // This method handles the instantiation of the games various elements
        columns = new ArrayList<>();
        random = new Random();

        setupGame();
        createColumns();
        showStartScreen();

        gamePane.setFocusTraversable(true);
        gamePane.requestFocus();

        // An event listener is used for the space bar functionality
        gamePane.setOnKeyPressed(event -> {
            if (!gameStarted && gameOverLabel.isVisible()) {
                if (event.getCode() == KeyCode.Y) {
                    startGame();
                } else if (event.getCode() == KeyCode.N) {
                    closeGame();
                }
            } else if (event.getCode() == KeyCode.SPACE) {
                handleSpaceKey();
            }
        });
    }

    private void setupGame() {
        // This method handles many things regarding game setup

        // Variables and Labels
        shark.setY(gamePane.getHeight() / 2);
        sharkVelocity = 0;
        score = 0;
        scoreLabel.setText("Score: " + score);

        // Column spacing
        for (int i = 0; i < columns.size(); i++) {
            double x = gamePane.getWidth() + i * columnSpacing;
            double height = random.nextInt(150) + 100;

            Rectangle topColumn = columns.get(i)[0];
            Rectangle bottomColumn = columns.get(i)[1];

            topColumn.setX(x);
            topColumn.setHeight(height);

            bottomColumn.setX(x);
            bottomColumn.setHeight(gamePane.getHeight() - height - gapHeight);
            bottomColumn.setY(height + gapHeight);
        }
    }

    private void createColumns() {
        // This method creates the columns in varying sizes and spacing
        int numColumns = 5;

        double totalWidth = gamePane.getWidth() - (numColumns - 1) * columnSpacing;

        double spaceBetweenColumns = totalWidth / numColumns;

        for (int i = 0; i < numColumns; i++) {
            double x = i * spaceBetweenColumns;
            double height = random.nextInt(150) + 100;

            Rectangle topColumn = new Rectangle(columnWidth, height, Color.LIGHTCYAN);
            topColumn.setX(x);
            topColumn.setY(0);

            Rectangle bottomColumn = new Rectangle(columnWidth, gamePane.getHeight() - height - gapHeight, Color.DARKOLIVEGREEN);
            bottomColumn.setX(x);
            bottomColumn.setY(height + gapHeight);

            gamePane.getChildren().addAll(topColumn, bottomColumn);
            columns.add(new Rectangle[]{topColumn, bottomColumn});
        }
    }


    private void startGame() {
        // This method calls the necessary functions to create the scene
        gameStarted = true;
        hideStartScreen();
        gameOverLabel.setVisible(false);
        setupGame();

        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updateShark();
                updateColumns();
                checkCollisions();
                updateScore();
            }
        };
        gameLoop.start();
    }

    private void updateShark() {
        // This method creates the movement of the shark on the y-axis
        double gravity = 0.5;
        sharkVelocity += gravity;
        shark.setY(shark.getY() + sharkVelocity);

        if (shark.getY() < 0) {
            shark.setY(0);
        }
        if (shark.getY() > gamePane.getHeight() - shark.getHeight()) {
            endGame();
        }
    }

    private void updateColumns() {
        // This method causes the constant generation of columns
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            double scrollSpeed = 5;
            topColumn.setX(topColumn.getX() - scrollSpeed);
            bottomColumn.setX(bottomColumn.getX() - scrollSpeed);

            if (topColumn.getX() + columnWidth < 0) {
                double x = gamePane.getWidth();
                double newHeight = random.nextInt(150) + 100;

                topColumn.setX(x);
                topColumn.setHeight(newHeight);

                bottomColumn.setX(x);
                bottomColumn.setHeight(gamePane.getHeight() - newHeight - gapHeight);
                bottomColumn.setY(newHeight + gapHeight);

                topColumn.setUserData(null);
            }
        }
    }

    private void checkCollisions() {
        // This method uses the location of the columns to compute collisions
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            if (shark.getBoundsInParent().intersects(topColumn.getBoundsInParent()) ||
                    shark.getBoundsInParent().intersects(bottomColumn.getBoundsInParent())) {
                endGame();
            }
        }
    }

    private void updateScore() {
        // This method keeps a running number of obstacles passed
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];

            if (topColumn.getX() + columnWidth < shark.getX() && topColumn.getUserData() == null) {
                score++;
                scoreLabel.setText("Score: " + score);
                topColumn.setUserData(true);
            }
        }
    }

    private void endGame() {
        // Handles ending logistics
        gameStarted = false;
        gameLoop.stop();
        showGameOver();
        gamePane.requestFocus();
    }

    private void showStartScreen() {
        // Handles showing starting text
        clickToStartLabel.setVisible(true);
        gameOverLabel.setVisible(false);
    }

    private void hideStartScreen() {
        // Handles hiding starting text
        clickToStartLabel.setVisible(false);
    }

    private void showGameOver() {
        // Handles showing ending text
        gameOverLabel.setText("   Game over!\nPlay again? y/n");
        gameOverLabel.setVisible(true);
    }

    private void closeGame() {
        // Is called to close the game when n is pressed in the event listener
        Stage stage = (Stage) gamePane.getScene().getWindow();
        stage.close();
    }

    public void handleSpaceKey() {
        // Ensures the space bar causes the shark to move
        if (gameStarted) {
            sharkVelocity = -7;
        } else {
            startGame();
        }
    }
}


