package com.example.demo3;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Random;

public class GameController {
    @FXML
    private Pane gamePane;

    @FXML
    private Rectangle shark;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label gameOverLabel;

    @FXML
    private Label clickToStartLabel;

    @FXML
    private ImageView sharkIMG;

    private double sharkVelocity = 0;
    private final double gravity = 0.5;
    private final double jumpStrength = -8;
    private int score = 0;

    private AnimationTimer gameLoop;
    private ArrayList<Rectangle[]> columns; // List of column pairs
    private Random random;

    private final double columnWidth = 60;
    private final double gapHeight = 200; // Space between top and bottom columns
    private final double columnSpacing = 300; // Space between pairs of columns
    private final double scrollSpeed = 5;

    private boolean gameStarted = false;

    @FXML
    public void initialize() {
        columns = new ArrayList<>();
        random = new Random();

        setupGame();
        createColumns();

        // Initial game state
        showStartScreen();

        // Enable focus for gamePane
        gamePane.setFocusTraversable(true);
        gamePane.requestFocus();

        // Handle mouse click for game start/restart
        gamePane.setOnMouseClicked(event -> {
            if (!gameStarted) {
                startGame();
            } else {
                sharkVelocity = jumpStrength; // Shark jumps on click
            }
            gamePane.requestFocus(); // Ensure focus after mouse click
        });

        // Handle keyboard input for replay, exit, or jump
        gamePane.setOnKeyPressed(event -> {
            if (!gameStarted && gameOverLabel.isVisible()) {
                if (event.getCode() == KeyCode.Y) {
                    startGame(); // Restart game
                } else if (event.getCode() == KeyCode.N) {
                    closeGame(); // Close window
                }
            } else if (event.getCode() == KeyCode.SPACE) {
                handleSpaceKey();
            }
        });
    }

    private void setupGame() {
        // Reset game state
        shark.setY(gamePane.getHeight() / 2);
        sharkVelocity = 0;
        score = 0;
        scoreLabel.setText("Score: " + score);

        // Reset columns
        for (int i = 0; i < columns.size(); i++) {
            double x = gamePane.getWidth() + i * columnSpacing;
            double height = random.nextInt(150) + 100;

            Rectangle topColumn = columns.get(i)[0];
            Rectangle bottomColumn = columns.get(i)[1];

            topColumn.setX(x);
            topColumn.setHeight(height);

            bottomColumn.setX(x);
            bottomColumn.setHeight(gamePane.getHeight() - height - gapHeight);
            bottomColumn.setY(height + gapHeight);
        }
    }

    private void createColumns() {
        // Calculate the number of columns
        int numColumns = 5;

        // Calculate the total available width for the columns
        double totalWidth = gamePane.getWidth() - (numColumns - 1) * columnSpacing; // Subtract the spacing between columns

        // Calculate the space between each column based on the available width
        double spaceBetweenColumns = totalWidth / numColumns;

        for (int i = 0; i < numColumns; i++) {
            // Calculate the x position of each column, evenly spaced
            double x = i * spaceBetweenColumns;

            // Random height for the top column
            double height = random.nextInt(150) + 100;

            // Create top column
            Rectangle topColumn = new Rectangle(columnWidth, height, Color.LIGHTCYAN);
            topColumn.setX(x);
            topColumn.setY(0);

            // Create bottom column
            Rectangle bottomColumn = new Rectangle(columnWidth, gamePane.getHeight() - height - gapHeight, Color.DARKOLIVEGREEN);
            bottomColumn.setX(x);
            bottomColumn.setY(height + gapHeight);

            // Add columns to the pane and the columns list
            gamePane.getChildren().addAll(topColumn, bottomColumn);
            columns.add(new Rectangle[]{topColumn, bottomColumn});
        }
    }


    private void startGame() {
        gameStarted = true;
        hideStartScreen();
        gameOverLabel.setVisible(false);
        setupGame();

        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updateShark();
                updateColumns();
                checkCollisions();
                updateScore();
            }
        };
        gameLoop.start();
    }

    private void updateShark() {
        sharkVelocity += gravity;
        shark.setY(shark.getY() + sharkVelocity);

        if (shark.getY() < 0) {
            shark.setY(0);
        }

        // End game if shark hits the ground
        if (shark.getY() > gamePane.getHeight() - shark.getHeight()) {
            endGame();
        }
    }

    private void updateColumns() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            // Move columns to the left
            topColumn.setX(topColumn.getX() - scrollSpeed);
            bottomColumn.setX(bottomColumn.getX() - scrollSpeed);

            // Reset columns if they leave the screen
            if (topColumn.getX() + columnWidth < 0) {
                double x = gamePane.getWidth();
                double newHeight = random.nextInt(150) + 100;

                topColumn.setX(x);
                topColumn.setHeight(newHeight);

                bottomColumn.setX(x);
                bottomColumn.setHeight(gamePane.getHeight() - newHeight - gapHeight);
                bottomColumn.setY(newHeight + gapHeight);

                topColumn.setUserData(null); // Reset score marker
            }
        }
    }

    private void checkCollisions() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            if (shark.getBoundsInParent().intersects(topColumn.getBoundsInParent()) ||
                    shark.getBoundsInParent().intersects(bottomColumn.getBoundsInParent())) {
                endGame();
            }
        }
    }

    private void updateScore() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];

            if (topColumn.getX() + columnWidth < shark.getX() && topColumn.getUserData() == null) {
                score++;
                scoreLabel.setText("Score: " + score);
                topColumn.setUserData(true); // Mark as scored
            }
        }
    }

    private void endGame() {
        gameStarted = false;
        gameLoop.stop();
        showGameOver();
        gamePane.requestFocus(); // Ensure focus after game ends
    }

    private void showStartScreen() {
        clickToStartLabel.setVisible(true);
        gameOverLabel.setVisible(false);
    }

    private void hideStartScreen() {
        clickToStartLabel.setVisible(false);
    }

    private void showGameOver() {
        gameOverLabel.setText("   Game over!\nPlay again? y/n");
        gameOverLabel.setVisible(true);
    }

    private void closeGame() {
        Stage stage = (Stage) gamePane.getScene().getWindow();
        stage.close();
    }

    public void handleSpaceKey() {
        if (gameStarted) {
            sharkVelocity = jumpStrength; // Shark jumps on space key press
        } else {
            startGame(); // Start game on first space key press
        }
    }
}


