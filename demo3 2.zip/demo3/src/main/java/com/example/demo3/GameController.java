package com.example.demo3;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Random;

public class GameController {
    @FXML
    private Pane gamePane;

    @FXML
    private Rectangle bird;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label gameOverLabel;

    @FXML
    private Label clickToStartLabel;

    private double birdVelocity = 0;
    private final double gravity = 0.5;
    private final double jumpStrength = -8;
    private int score = 0;

    private AnimationTimer gameLoop;
    private ArrayList<Rectangle[]> columns; // List of column pairs
    private Random random;

    private final double columnWidth = 60;
    private final double gapHeight = 200; // Space between top and bottom columns
    private final double columnSpacing = 300; // Space between pairs of columns
    private final double scrollSpeed = 5;

    private boolean gameStarted = false;

    @FXML
    public void initialize() {
        columns = new ArrayList<>();
        random = new Random();

        setupGame();
        createColumns();

        // Initial game state
        showStartScreen();

        // Handle mouse click for game start/restart
        gamePane.setOnMouseClicked(event -> {
            if (!gameStarted) {
                startGame();
            } else {
                birdVelocity = jumpStrength; // Bird jumps on click
            }
        });

        // Handle keyboard input for replay or exit
        gamePane.setOnKeyPressed(event -> {
            if (!gameStarted && gameOverLabel.isVisible()) {
                if (event.getCode() == KeyCode.Y) {
                    startGame(); // Restart game
                } else if (event.getCode() == KeyCode.N) {
                    closeGame(); // Close window
                }
            }
        });
    }

    private void setupGame() {
        // Reset game state
        bird.setY(gamePane.getHeight() / 2);
        birdVelocity = 0;
        score = 0;
        scoreLabel.setText("Score: " + score);

        // Reset columns
        for (int i = 0; i < columns.size(); i++) {
            double x = gamePane.getWidth() + i * columnSpacing;
            double height = random.nextInt(150) + 100;

            Rectangle topColumn = columns.get(i)[0];
            Rectangle bottomColumn = columns.get(i)[1];

            topColumn.setX(x);
            topColumn.setHeight(height);

            bottomColumn.setX(x);
            bottomColumn.setHeight(gamePane.getHeight() - height - gapHeight);
            bottomColumn.setY(height + gapHeight);
        }
    }

    private void createColumns() {
        for (int i = 0; i < 5; i++) {
            double x = gamePane.getWidth() + i * columnSpacing;
            double height = random.nextInt(150) + 100;

            // Create top column
            Rectangle topColumn = new Rectangle(columnWidth, height, Color.GREEN);
            topColumn.setX(x);
            topColumn.setY(0);

            // Create bottom column
            Rectangle bottomColumn = new Rectangle(columnWidth, gamePane.getHeight() - height - gapHeight, Color.GREEN);
            bottomColumn.setX(x);
            bottomColumn.setY(height + gapHeight);

            gamePane.getChildren().addAll(topColumn, bottomColumn);
            columns.add(new Rectangle[]{topColumn, bottomColumn});
        }
    }

    private void startGame() {
        gameStarted = true;
        hideStartScreen();
        gameOverLabel.setVisible(false);
        setupGame();

        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updateBird();
                updateColumns();
                checkCollisions();
                updateScore();
            }
        };
        gameLoop.start();
    }

    private void updateBird() {
        birdVelocity += gravity;
        bird.setY(bird.getY() + birdVelocity);

        if (bird.getY() < 0) {
            bird.setY(0);
        }

        // End game if bird hits the ground
        if (bird.getY() > gamePane.getHeight() - bird.getHeight()) {
            endGame();
        }
    }

    private void updateColumns() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            // Move columns to the left
            topColumn.setX(topColumn.getX() - scrollSpeed);
            bottomColumn.setX(bottomColumn.getX() - scrollSpeed);

            // Reset columns if they leave the screen
            if (topColumn.getX() + columnWidth < 0) {
                double x = gamePane.getWidth();
                double newHeight = random.nextInt(150) + 100;

                topColumn.setX(x);
                topColumn.setHeight(newHeight);

                bottomColumn.setX(x);
                bottomColumn.setHeight(gamePane.getHeight() - newHeight - gapHeight);
                bottomColumn.setY(newHeight + gapHeight);

                topColumn.setUserData(null); // Reset score marker
            }
        }
    }

    private void checkCollisions() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];
            Rectangle bottomColumn = columnPair[1];

            if (bird.getBoundsInParent().intersects(topColumn.getBoundsInParent()) ||
                    bird.getBoundsInParent().intersects(bottomColumn.getBoundsInParent())) {
                endGame();
            }
        }
    }

    private void updateScore() {
        for (Rectangle[] columnPair : columns) {
            Rectangle topColumn = columnPair[0];

            if (topColumn.getX() + columnWidth < bird.getX() && topColumn.getUserData() == null) {
                score++;
                scoreLabel.setText("Score: " + score);
                topColumn.setUserData(true); // Mark as scored
            }
        }
    }

    private void endGame() {
        gameStarted = false;
        gameLoop.stop();
        showGameOver();
    }

    public void handleSpaceKey() {
        if (gameStarted) {
            birdVelocity = jumpStrength; // Bird jumps on space key press
        } else {
            startGame(); // Start game on first space key press
        }
    }

    private void showStartScreen() {
        clickToStartLabel.setVisible(true);
        gameOverLabel.setVisible(false);
    }

    private void hideStartScreen() {
        clickToStartLabel.setVisible(false);
    }

    private void showGameOver() {
        gameOverLabel.setText("Game over, play again?");
        gameOverLabel.setVisible(true);
    }

    private void closeGame() {
        Stage stage = (Stage) gamePane.getScene().getWindow();
        stage.close();
    }
}

