package com.example.demo3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FlappyBirdApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        // Load the FXML file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
        Scene scene = new Scene(loader.load(), 800, 600);

        // Attach the key press event for the spacebar
        scene.setOnKeyPressed(event -> {
            if (event.getCode().toString().equals("SPACE")) {
                // Call the controller method to handle spacebar press
                GameController controller = loader.getController();
                controller.handleSpaceKey();
            }
        });

        // Set the scene to the stage and display the window
        stage.setTitle("Flappy Bird");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
